import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Choco here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Choco extends Actor
{
    private int cookiesEaten;
    
    /**
     * Act - do whatever the Choco wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        moveAround();
        lookForCookie();
    }
    
    public void moveAround()
    {
    if (Greenfoot.isKeyDown("left")) setLocation(getX()-5, getY());
    if (Greenfoot.isKeyDown("right")) setLocation(getX()+5, getY());
    if (Greenfoot.isKeyDown("up")) setLocation(getX(), getY()-5);
    if (Greenfoot.isKeyDown("down")) setLocation(getX(), getY()+5);
    }
    
    public void lookForCookie() 
    {
    if (isTouching(Cookie.class)) {
        removeTouching(Cookie.class);
        cookiesEaten = cookiesEaten + 1;
    }
    }
}